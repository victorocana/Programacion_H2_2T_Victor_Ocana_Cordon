<?php
session_start(); // Iniciamos la sesión
include './conexion.php';

if ($conexion->connect_error) {
    die('Error de Conexión (' . $conexion->connect_errno . ') ' . $conexion->connect_error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Usuario</title>
</head>
   <link rel="stylesheet" href="php.css">
<body>
    <form action="login.php" method="POST">
        <br>
        <label><b>Email:</b></label>
        <input type="email" name="email" required>
        <br><br>
        <label><b>Contraseña:</b></label>
        <input type="password" name="password" required>
        <br>
        <button type="submit" id="inicio">INICIAR SESION</button>
        <a href="portal.php" class="button" >Atras</a>
        <br>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        
        $email = $_REQUEST["email"];// Obtenemos el email del formulario
        $Contrasena = $_REQUEST["password"];// Obtenemos la clave del formulario     
         // Verificar si el email y la clave ya existe en la base de datos y coincide
    $sql = "SELECT * FROM Alumno WHERE Email = '$email' AND Contrasena = '$Contrasena'";
    $result = $conexion->query($sql);
    
    if ($result->num_rows > 0) {
        // Si el email existe, iniciamos la sesión
         // Guardamos el email en la sesión
        $_SESSION['email'] = $email;
        header("Location: tablon.php"); // Redirigimos al usuario a TareaAlumno.php
        
    } else {
        // Si las credenciales no coinciden, mostramos un error
        $error_message = "Error: Credenciales erroneas.";
        echo $error_message;
    }
}


    $conexion->close();
    ?>
</body>
</html>
