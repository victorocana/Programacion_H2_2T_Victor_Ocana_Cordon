<!DOCTYPE html>
<html lang="es">
<head>
    <!-- Metadatos de la página, como la codificación y la configuración de la vista -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tablón Alumno</title>
</head>
    <link rel="stylesheet" href="php.css">
<body>
    <!-- Barra de navegación  -->
    <nav>
        <a href="portal.php" class="nav-link">Inicio</a>

        <a href="TareaAlumno.php" class="nav-link">Buscar Tarea</a>
    </nav>
    <br><br>

    <!-- Pedimos los datos del usuario. -->
    <br>
<form  method="POST">
   <h1>Agregar Tareas</h1>
    <br>

    <b>Asignatura:</b>
    <input type="checkbox" name="Programacion" value="1"> PROGRAMACIÓN
    <input type="checkbox" name="BBDD" value="1"> BBDD
    <input type="checkbox" name="FOL" value="1"> FOL
    <br><br>
    <b>Tarea: </b>
    <select name="Tarea">
        <option value="" disabled selected>Selecciona una Tarea</option>
        <option value="Empezar a trabajar">Empezar a trabajar</option>
        <option value="Preguntar dudas al profesor">Preguntar dudas al profesor</option>
    </select>
    <br><br>
    <b>Prioridad: </b>
    <select name="Prioridad">
        <option value="ALTA">ALTA</option>
        <option value="BAJA">BAJA</option>
    </select>
    <br><br>
        <b>Estado: </b>
        <Select name="Estado">
            <OPTION VALUE="Pendiente">Pendiente
            <OPTION VALUE="Completado">Completado
        </select>
        <br><br>
    <button type="submit" id="inicio">Enviar</button>
                <a href="portal.php" class="button">Atras</a>
</form>

<?php
session_start(); // Iniciamos la sesión

// Verificar si la sesión está activa (es decir, si el email está guardado)
if (!isset($_SESSION['email'])) {
    die("Error: No hay sesión iniciada.");
}

$email = $_SESSION['email']; // Obtenemos el email de la sesión

// Conectamos con la base de datos
include_once './conexion.php';  // Asegúrate de que este archivo está bien configurado

$conexion = new mysqli("127.0.0.1", "root", "campusfp", "Alumno_VOC");

// Verificar si la conexión es exitosa
if ($conexion->connect_error) {
    die('Error de Conexión (' . $conexion->connect_errno . ') ' . $conexion->connect_error);
}

// Verificar si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los valores del formulario
    $Programacion = isset($_POST['Programacion']) ? 1 : 0;
    $BBDD = isset($_POST['BBDD']) ? 1 : 0;
    $FOL = isset($_POST['FOL']) ? 1 : 0;
    $Tarea = isset($_POST['Tarea']) ? $_POST['Tarea'] : '';
    $Prioridad = isset($_POST['Prioridad']) ? $_POST['Prioridad'] : '';
    $Estado = isset($_POST['Estado']) ? $_POST['Estado'] : '';

    // Validar que los campos obligatorios no estén vacíos
    if (empty($Tarea) || empty($Prioridad) || empty($Estado)) {
        echo "<h2>Error: Debes seleccionar una tarea, una prioridad y el estado.</h2>";
    } else {
        // Construir la consulta SQL
        $sql = "INSERT INTO tablon (Email, Programacion, BBDD, FOL, Tarea, Prioridad, Estado) 
                VALUES ('$email', $Programacion, $BBDD, $FOL, '$Tarea', '$Prioridad', '$Estado');";

        // Ejecutar la consulta
        if ($conexion->query($sql) === TRUE) {
            echo "<h2>Se ha guardado la tarea correctamente.</h2>";
        } else {
            echo "<h2>Error al registrar la tarea: " . $conexion->error . "</h2>";
        }
    }
}

$conexion->close();
?>
  
</body>
</html>

