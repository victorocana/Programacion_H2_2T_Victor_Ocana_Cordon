<?php
session_start();
// Aquí puedes gestionar la lógica de inicio de sesión y registro.
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal de Usuario</title>
   
</head>
   <link rel="stylesheet" href="php.css">
<body>

<div class="container">
    <h1>Bienvenido</h1>
    <p>Por favor elige una opción:</p>
    <a href="login.php" class="button" id="inicio">Iniciar Sesión</a>
    <a href="Registro.php" class="button" id="registro">Registrarse</a>
</div>

</body>
</html>