<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Usuario</title>
    <link rel="stylesheet" href="php.css">
</head>
<body>
    <h1>Rellene Formulario</h1>
    <br>
    <form action="" method="POST">
        <label><b>Nombre:</b></label>
        <input type="text" name="Nombre" required>
        <br><br>
        <label><b>Apellido:</b></label>
        <input type="text" name="Apellido" required>
        <br><br>
        <label><b>Contraseña:</b></label>
        <input type="password" name="password" required>
        <br><br>
        <label><b>Email:</b></label>
        <input type="email" name="email" required>
        <br>
        
        <input type="checkbox" name="aceptar_politicas" required>
        <label for="aceptar_politicas"> He leído y acepto las politicas y el uso de ellas para el hito.</label>
        <br><br>

        <button type="submit" id="inicio">Registrar</button>
        <a href="portal.php" class="button">Atrás</a>
    </form>
    
    <?php
    include './conexion.php';

    if ($conexion->connect_error) {
        die('Error de Conexión (' . $conexion->connect_errno . ') ' . $conexion->connect_error);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $Nombre = $_REQUEST["Nombre"];
        $Apellido = $_REQUEST["Apellido"];
        $Contrasena = $_REQUEST["password"];
        $email = $_REQUEST["email"];
        $aceptar_politicas = isset($_POST["aceptar_politicas"]); // Comprobar si el checkbox está marcado
        
        if (!$aceptar_politicas) {
            echo "<h2>Error: Debes aceptar las políticas para registrarte.</h2>";
        } else {
            // Verificar si el email ya está registrado
            $emailverifica = "SELECT * FROM tablon WHERE Email = '$email'";
            $result = $conexion->query($emailverifica);
    
            if ($result->num_rows > 0) {
                echo "<h2>Error: El Usuario con email " . $email . " ya está registrado.</h2>";
            } else {
                // Hashear la contraseña antes de almacenarla
                $hashed_password = password_hash($Contrasena, PASSWORD_BCRYPT);
    
                // Insertar el nuevo usuario en la base de datos con la contraseña hasheada
                $sql = "INSERT INTO Alumno(Nombre, Apellido, Contrasena, Email)
                        VALUES ('$Nombre', '$Apellido', '$hashed_password', '$email');";
    
                if ($conexion->query($sql)) {
                    echo "<h2>Se ha dado de alta al Alumno: $Nombre $Apellido.</h2>";
                    ?>
                    <a href="login.php" id="inicio">INICIAR SESION</a>
                    <?php            
                } else {
                    echo "<h2>Error al registrar el Alumno: " . $conexion->error . "</h2>";
                }
            }
        }
    }
    
    if (isset($_GET['error']) && $_GET['error'] == 'no_user') {
        echo "<h2 style='color: red;'>Error: Usuario no registrado.</h2>";
    }

    $conexion->close();
    ?>
</body>
</html>