<?php
session_start(); // Iniciamos la sesión

// Verificar si la sesión está activa (es decir, si el email está guardado)
if (!isset($_SESSION['email'])) {
    die("Error: No hay sesión iniciada.");
}

$email = $_SESSION['email']; // Obtenemos el email de la sesión

// Conectamos con la base de datos
include_once './conexion.php';  // Asegúrate de que este archivo está bien configurado

$conexion = new mysqli("127.0.0.1", "root", "campusfp", "Alumno_VOC");

// Verificar si la conexión es exitosa
if ($conexion->connect_error) {
    die('Error de Conexión (' . $conexion->connect_errno . ') ' . $conexion->connect_error);
}

// Controlamos la acción de eliminar
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['eliminar'])) {
     // Uso el id de la tarea para eliminarla
    $id_tarea = $_POST['id_tarea']; 
    // Eliminamos la tarea por su id
    $sql = "DELETE FROM tablon WHERE id = '$id_tarea'";  
    if ($conexion->query($sql) === TRUE) {
        echo "<p>Tarea eliminada correctamente.</p>";
    } else {
        echo "<p>Error al eliminar la tarea: " . $conexion->error . "</p>";
    }
}

// Manejar la acción de actualizar
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['actualizar'])) {
    $email = $_POST['Email'];
    echo "<h2>Actualizar Tarea</h2><br>";
    echo "<form action='' method='POST'>
            <input type='hidden' name='Email' value='$email'>
            Nueva Tarea: 
                <select name='nueva_tarea'>
                <option value='' disabled selected>Selecciona una Tarea</option>
                <option value='Empezar a trabajar'>Empezar a trabajar</option>
                <option value='Preguntar dudas al profesor'>Preguntar dudas al profesor</option>
            </select><br>
            Nueva Prioridad: 
            <select name='nueva_prioridad'>
                <option value='ALTA'>ALTA</option>
                <option value='BAJA'>BAJA</option>
            </select><br>
            Nuevo Estado: 
            <select name='nuevo_estado'>
                <option value='Pendiente'>Pendiente</option>
                <option value='Completado'>Completado</option>
            </select><br>
            <button type='submit' name='guardar_cambios'>Guardar Cambios</button>
          </form>";
}

// Guardar cambios después de actualizar
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['guardar_cambios'])) {
    $email = $_POST['Email'];
    $Tarea = $_POST['nueva_tarea']; 
    $Prioridad = $_POST['nueva_prioridad'];  
    $Estado = $_POST['nuevo_estado']; 

    $sql = "UPDATE tablon SET 
            Tarea = '$Tarea', 
            Prioridad = '$Prioridad', 
            Estado = '$Estado' 
            WHERE Email = '$email'";
    if ($conexion->query($sql)) {
        echo "<p>Tarea actualizada correctamente.</p>";
    } else {
        echo "<p>Error al actualizar la tarea: " . $conexion->error . "</p>";
    }
}

// Realizamos la consulta SQL para obtener las tareas del usuario basado en el email de la sesión
$sql = "SELECT 
    T.id,  -- ID de la tarea
    A.Email, 
    T.Tarea,
    T.Programacion AS Programacion,
    T.BBDD AS BBDD,
    T.FOL AS FOL,
    T.Prioridad, 
    T.Estado
FROM Alumno A
INNER JOIN tablon T ON A.Email = T.Email
WHERE A.Email = '$email';";

// Ejecutar la consulta
$resultado = $conexion->query($sql);
if (!$resultado) {
    die("Error en la consulta: " . $conexion->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tabla de Alumno</title>
    <link rel="stylesheet" href="php.css">
</head>
<body>
    <!-- Barra de navegación -->
    <nav>
        <a href="portal.php" class="nav-link">Inicio</a>
        <a href="tablon.php" class="nav-link">Añadir Tarea</a>
    </nav>

    <br><br><br>
    
    <?php
    // Mostrar los resultados solo si se han encontrado tareas
    if (isset($resultado) && $resultado->num_rows > 0) {
    ?>
        <table>
            <thead>
                <tr> 
                    <th>Email</th> 
                    <th>Tarea</th>
                    <th>PROGRAMACIÓN</th>
                    <th>BBDD</th>
                    <th>FOL</th>
                    <th>PRIORIDAD</th>
                    <th>ESTADO</th>
                    <th>ACCIÓN</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = $resultado->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['Email'] . "</td>";
                    echo "<td>" . $row['Tarea'] . "</td>";
                    echo "<td>" . ($row['Programacion'] ? 'Sí' : 'No') . "</td>";
                    echo "<td>" . ($row['BBDD'] ? 'Sí' : 'No') . "</td>";
                    echo "<td>" . ($row['FOL'] ? 'Sí' : 'No') . "</td>";
                    echo "<td>" . $row['Prioridad'] . "</td>";
                    echo "<td>" . $row['Estado'] . "</td>";
                    echo "<td>
                        <!-- Botón para eliminar -->
                        <form action='' method='POST' style='display:inline;'>
                        <!-- Pasamos el id de la tarea -->
                            <input type='hidden' name='id_tarea' value='" . $row['id'] . "'>  
                            <button type='submit' name='eliminar'>Eliminar</button>
                        </form>
                        <!-- Botón para actualizar -->
                        <form action='' method='POST' style='display:inline;'>
                            <input type='hidden' name='Email' value='" . $row['Email'] . "'>
                            <button type='submit' name='actualizar'>Actualizar</button>
                        </form>
                    </td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    <?php
    } else {
        echo "<p>No se encontraron tareas para el Alumno con el email: $email.</p>";
    }
    ?>

    <a href="logout.php" class="button">CERRAR SESIÓN</a>
</body>
</html>
