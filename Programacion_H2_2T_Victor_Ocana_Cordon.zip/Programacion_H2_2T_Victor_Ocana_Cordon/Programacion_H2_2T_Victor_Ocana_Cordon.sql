drop database if exists Alumno_VOC;
CREATE DATABASE Alumno_VOC;
USE Alumno_VOC;
drop table if exists Alumno;
CREATE TABLE Alumno (
    Nombre VARCHAR(255),                      
    Apellido VARCHAR(255) ,
    Contrasena VARCHAR(255) NOT NULL, 
    Email varchar(250) unique	
);

DROP TABLE IF EXISTS tablon;
CREATE TABLE tablon (
id int auto_increment primary key,
    Email varchar(250),
    Tarea ENUM('Empezar a trabajar', 'Preguntar dudas al profesor'),
    Programacion boolean,
    BBDD boolean,
    FOL boolean,
    Prioridad ENUM('Alta', 'Baja'),
    Estado ENUM('Pendiente', 'Completado'),
    FOREIGN KEY (Email) REFERENCES Alumno(Email)
);

SELECT 
T.id,
    A.Email, 
    T.Tarea,
    T.Programacion AS Programacion,
    T.BBDD AS BBDD,
    T.FOL AS FOL,
    T.Prioridad, 
	T.Estado
FROM Alumno A
inner JOIN tablon T ON A.Email = T.Email;

select * from tablon;
select * from Alumno; 		
delete from Alumno where Email='campus@gmail.com' ;	
delete from tablon where Email='campus@gmail.com' ;	
DESCRIBE Alumno;
DESCRIBE tablon;



